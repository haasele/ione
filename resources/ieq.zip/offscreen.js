'use strict';

const tabAudio = new Map();
const VALID_FILTER_TYPES = new Set(['peaking', 'lowshelf', 'highshelf']);

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function toFiniteNumber(value, fallback) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function sanitizeFilter(filter) {
  if (!filter || !VALID_FILTER_TYPES.has(filter.type)) {
    return null;
  }

  return {
    type: filter.type,
    frequency: clamp(toFiniteNumber(filter.frequency, 1000), 10, 24000),
    q: clamp(toFiniteNumber(filter.q, 1), 0.01, 1000),
    gain: clamp(toFiniteNumber(filter.gain, 0), -100, 100)
  };
}

function buildFilterNodes(context, filters) {
  const nodes = [];
  for (const filter of filters) {
    const safeFilter = sanitizeFilter(filter);
    if (!safeFilter) {
      continue;
    }

    const node = context.createBiquadFilter();
    node.type = safeFilter.type;
    node.frequency.value = safeFilter.frequency;
    node.gain.value = safeFilter.gain;
    node.Q.value = safeFilter.q;
    nodes.push(node);
  }
  return nodes;
}

function applyFilterValues(nodes, filters) {
  for (let i = 0; i < nodes.length; i += 1) {
    const safeFilter = sanitizeFilter(filters[i]);
    if (!safeFilter) {
      continue;
    }

    const node = nodes[i];
    node.type = safeFilter.type;
    node.frequency.value = safeFilter.frequency;
    node.gain.value = safeFilter.gain;
    node.Q.value = safeFilter.q;
  }
}

function notifyCaptureEnded(tabId) {
  chrome.runtime.sendMessage({ type: 'tabCaptureEnded', tabId }).catch(() => {
    // The service worker may be asleep; Chrome will wake it for this message.
  });
}

async function teardownTab(tabId, { notify = false } = {}) {
  const session = tabAudio.get(tabId);
  if (!session) {
    return;
  }

  tabAudio.delete(tabId);

  if (session.track && session.onTrackEnded) {
    session.track.removeEventListener('ended', session.onTrackEnded);
  }
  session.stream.getTracks().forEach((track) => track.stop());
  session.filterNodes.forEach((node) => node.disconnect());
  session.gainNode.disconnect();
  session.analyser.disconnect();
  session.source.disconnect();

  try {
    await session.context.close();
  } catch (error) {
    console.warn('ieq: unable to close audio context:', error);
  }

  if (notify) {
    notifyCaptureEnded(tabId);
  }
}

async function startTabAudio(tabId, streamId, filters, gain) {
  if (!Number.isInteger(tabId)) {
    throw new Error('Invalid tab id.');
  }
  if (typeof streamId !== 'string' || !streamId) {
    throw new Error('Missing tab capture stream id.');
  }

  const existing = tabAudio.get(tabId);
  if (existing) {
    return { ok: true, sampleRate: existing.context.sampleRate, state: existing.context.state };
  }

  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: {
        chromeMediaSource: 'tab',
        chromeMediaSourceId: streamId
      }
    },
    video: false
  });

  const track = stream.getAudioTracks()[0];
  if (!track) {
    stream.getTracks().forEach((streamTrack) => streamTrack.stop());
    throw new Error('The captured tab did not provide an audio track.');
  }

  let context = null;
  try {
    context = new AudioContext();
    const source = context.createMediaStreamSource(stream);
    const gainNode = context.createGain();
    gainNode.gain.value = clamp(toFiniteNumber(gain, 1), 0, 10);

    const analyser = context.createAnalyser();
    analyser.fftSize = 512;
    analyser.smoothingTimeConstant = 0.7;

    const filterNodes = buildFilterNodes(
      context,
      Array.isArray(filters) ? filters : []
    );

    let previous = source;
    for (const filterNode of filterNodes) {
      previous.connect(filterNode);
      previous = filterNode;
    }
    previous.connect(gainNode);
    gainNode.connect(analyser);
    analyser.connect(context.destination);

    const session = {
      stream,
      track,
      context,
      source,
      filterNodes,
      gainNode,
      analyser,
      onTrackEnded: null
    };

    session.onTrackEnded = () => {
      void teardownTab(tabId, { notify: true });
    };
    track.addEventListener('ended', session.onTrackEnded);

    tabAudio.set(tabId, session);

    // Offscreen documents have no user activation of their own. Chrome normally
    // lets captured tab audio play, but resume defensively so the graph runs.
    if (context.state === 'suspended') {
      await context.resume().catch((error) => {
        console.warn('ieq: unable to resume audio context:', error);
      });
    }

    return { ok: true, sampleRate: context.sampleRate, state: context.state };
  } catch (error) {
    stream.getTracks().forEach((streamTrack) => streamTrack.stop());
    if (context) {
      await context.close().catch(() => {});
    }
    throw error;
  }
}

async function stopTabAudio(tabId) {
  await teardownTab(tabId);
  return { ok: true };
}

function updateAllFilters(filters, gain) {
  const safeFilters = Array.isArray(filters) ? filters : [];
  for (const session of tabAudio.values()) {
    applyFilterValues(session.filterNodes, safeFilters);
    session.gainNode.gain.value = clamp(toFiniteNumber(gain, 1), 0, 10);
  }
}

function getFFT(tabId) {
  const session = tabAudio.get(tabId);
  if (!session) {
    return { fft: [] };
  }

  const values = new Float32Array(session.analyser.frequencyBinCount);
  session.analyser.getFloatFrequencyData(values);

  // -Infinity cannot cross the extension messaging boundary; clamp it so the
  // visualizer draws a baseline instead of nulls.
  return {
    fft: Array.from(values, (value) =>
      Number.isFinite(value) ? clamp(value, -100, 0) : -100
    )
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.target !== 'offscreen') {
    return false;
  }

  void (async () => {
    switch (message.command) {
      case 'startTabAudio':
        sendResponse(
          await startTabAudio(message.tabId, message.streamId, message.filters, message.gain)
        );
        return;
      case 'stopTabAudio':
        sendResponse(await stopTabAudio(message.tabId));
        return;
      case 'updateAllFilters':
        updateAllFilters(message.filters, message.gain);
        sendResponse({ ok: true });
        return;
      case 'getFFT':
        sendResponse(getFFT(message.tabId));
        return;
      case 'getActiveTabs':
        sendResponse({ tabIds: Array.from(tabAudio.keys()) });
        return;
      default:
        sendResponse({ ok: false, error: `Unknown offscreen command: ${message.command}` });
    }
  })().catch((error) => {
    console.error('ieq offscreen error:', error);
    sendResponse({ ok: false, error: error.message });
  });

  return true;
});
