'use strict';

const OFFSCREEN_PATH = 'offscreen.html';
const OFFSCREEN_URL = chrome.runtime.getURL(OFFSCREEN_PATH);
const PRESETS_STORAGE_KEY = 'ieq_presets_v1';
const LEGACY_PRESETS_STORAGE_KEY = 'ears_presets_v1';
const WORKSPACE_STORAGE_KEY = 'ieq_workspace_v1';
const LEGACY_WORKSPACE_STORAGE_KEY = 'ears_workspace_v1';

const ACTION_ICON_ON = {
  16: 'logo/ieq-16.png',
  32: 'logo/ieq-32.png',
  48: 'logo/ieq-48.png',
  64: 'logo/ieq-64.png',
  128: 'logo/ieq-128.png'
};

const ACTION_ICON_OFF = {
  16: 'logo/ieq-off-16.png',
  32: 'logo/ieq-off-32.png',
  48: 'logo/ieq-off-48.png',
  64: 'logo/ieq-off-64.png',
  128: 'logo/ieq-off-128.png'
};

const DEFAULT_FILTERS = [
  { type: 'lowshelf', frequency: 60, q: 0.7, gain: 0 },
  { type: 'peaking', frequency: 170, q: 1, gain: 0 },
  { type: 'peaking', frequency: 310, q: 1, gain: 0 },
  { type: 'peaking', frequency: 600, q: 1, gain: 0 },
  { type: 'peaking', frequency: 1000, q: 1, gain: 0 },
  { type: 'peaking', frequency: 3000, q: 1, gain: 0 },
  { type: 'peaking', frequency: 6000, q: 1, gain: 0 },
  { type: 'peaking', frequency: 12000, q: 1, gain: 0 },
  { type: 'highshelf', frequency: 14000, q: 0.7, gain: 0 }
];

const VALID_FILTER_TYPES = new Set(['peaking', 'lowshelf', 'highshelf']);
const FILTER_COUNT = DEFAULT_FILTERS.length;

const FILTER_FREQ_RANGE = [10, 24000];
const FILTER_Q_RANGE = [0.01, 1000];
const FILTER_GAIN_RANGE = [-100, 100];
const VOLUME_GAIN_RANGE = [0, 10];
const SAMPLE_RATE_RANGE = [8000, 384000];
const MAX_IMPORTED_PRESETS = 500;
const MAX_PRESET_NAME_LENGTH = 120;
const RESERVED_PRESET_NAMES = new Set(['__proto__', 'constructor', 'prototype']);

const RESPONDING_MESSAGE_TYPES = new Set([
  'PING',
  'eqTab',
  'getFFT',
  'savePreset',
  'deletePreset',
  'importPresets',
  'exportPresets'
]);

const workspace = {
  eqFilters: DEFAULT_FILTERS.map((filter) => ({ ...filter })),
  gain: 1,
  sampleRate: 44100,
  streams: [],
  presets: Object.create(null)
};

const startingTabs = new Set();
const actionIconStates = new Map();

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function toFiniteNumber(value, fallback) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function sanitizeFilter(inputFilter, fallbackFilter) {
  const fallback = fallbackFilter || DEFAULT_FILTERS[0];
  const type = VALID_FILTER_TYPES.has(inputFilter?.type) ? inputFilter.type : fallback.type;

  return {
    type,
    frequency: clamp(
      toFiniteNumber(inputFilter?.frequency, fallback.frequency),
      FILTER_FREQ_RANGE[0],
      FILTER_FREQ_RANGE[1]
    ),
    q: clamp(toFiniteNumber(inputFilter?.q, fallback.q), FILTER_Q_RANGE[0], FILTER_Q_RANGE[1]),
    gain: clamp(
      toFiniteNumber(inputFilter?.gain, fallback.gain),
      FILTER_GAIN_RANGE[0],
      FILTER_GAIN_RANGE[1]
    )
  };
}

function sanitizeFilterList(rawFilters) {
  const list = Array.isArray(rawFilters) ? rawFilters : [];
  return DEFAULT_FILTERS.map((fallback, index) => sanitizeFilter(list[index], fallback));
}

function sanitizeVolumeGain(value) {
  return clamp(toFiniteNumber(value, 1), VOLUME_GAIN_RANGE[0], VOLUME_GAIN_RANGE[1]);
}

function sanitizeSampleRate(value) {
  const rate = toFiniteNumber(value, 44100);
  return rate >= SAMPLE_RATE_RANGE[0] && rate <= SAMPLE_RATE_RANGE[1] ? rate : 44100;
}

function sanitizeStreams(rawStreams) {
  if (!Array.isArray(rawStreams)) {
    return [];
  }

  const seen = new Set();
  const streams = [];
  for (const rawStream of rawStreams) {
    const id = Number(rawStream?.id);
    if (!Number.isInteger(id) || seen.has(id)) {
      continue;
    }
    seen.add(id);
    streams.push({
      id,
      title: typeof rawStream.title === 'string' && rawStream.title ? rawStream.title : `Tab ${id}`,
      favIconUrl: typeof rawStream.favIconUrl === 'string' ? rawStream.favIconUrl : ''
    });
  }
  return streams;
}

function normalizePresetValue(rawPreset) {
  if (!rawPreset) {
    return null;
  }

  const rawFilters = Array.isArray(rawPreset.eqFilters)
    ? rawPreset.eqFilters
    : Array.isArray(rawPreset.filters)
      ? rawPreset.filters
      : Array.isArray(rawPreset)
        ? rawPreset
        : null;

  if (!rawFilters) {
    return null;
  }

  return {
    eqFilters: sanitizeFilterList(rawFilters),
    gain: sanitizeVolumeGain(rawPreset.gain)
  };
}

function isValidPresetName(name) {
  return (
    typeof name === 'string' &&
    name.length > 0 &&
    name.length <= MAX_PRESET_NAME_LENGTH &&
    !RESERVED_PRESET_NAMES.has(name)
  );
}

function normalizeImportedPresets(rawPresets) {
  const source =
    rawPresets?.presets && typeof rawPresets.presets === 'object'
      ? rawPresets.presets
      : rawPresets;

  if (!source || typeof source !== 'object' || Array.isArray(source)) {
    return Object.create(null);
  }

  const normalized = Object.create(null);
  let processed = 0;
  for (const name of Object.keys(source)) {
    if (processed >= MAX_IMPORTED_PRESETS) {
      break;
    }
    processed += 1;
    if (!isValidPresetName(name)) {
      continue;
    }
    const parsed = normalizePresetValue(source[name]);
    if (parsed) {
      normalized[name] = parsed;
    }
  }
  return normalized;
}

function workspaceSnapshot() {
  return {
    eqFilters: workspace.eqFilters.map((filter) => ({ ...filter })),
    gain: workspace.gain,
    sampleRate: workspace.sampleRate,
    streams: workspace.streams.map((stream) => ({ ...stream }))
  };
}

let initPromise = null;
let persistTimer = null;

function initWorkspace() {
  if (!initPromise) {
    initPromise = loadWorkspace().catch((error) => {
      console.error('ieq: unable to restore workspace:', error);
    });
  }
  return initPromise;
}

async function loadWorkspace() {
  const [storedPresets, storedWorkspace] = await Promise.all([
    chrome.storage.local.get([
      PRESETS_STORAGE_KEY,
      LEGACY_PRESETS_STORAGE_KEY
    ]),
    chrome.storage.session.get([
      WORKSPACE_STORAGE_KEY,
      LEGACY_WORKSPACE_STORAGE_KEY
    ])
  ]);

  let rawPresets = storedPresets[PRESETS_STORAGE_KEY];
  if (
    rawPresets === undefined &&
    storedPresets[LEGACY_PRESETS_STORAGE_KEY] !== undefined
  ) {
    rawPresets = storedPresets[LEGACY_PRESETS_STORAGE_KEY];
    await chrome.storage.local.set({ [PRESETS_STORAGE_KEY]: rawPresets });
  }
  workspace.presets = normalizeImportedPresets(rawPresets);

  let saved = storedWorkspace[WORKSPACE_STORAGE_KEY];
  let usedLegacyWorkspace = false;
  if (
    saved === undefined &&
    storedWorkspace[LEGACY_WORKSPACE_STORAGE_KEY] !== undefined
  ) {
    saved = storedWorkspace[LEGACY_WORKSPACE_STORAGE_KEY];
    usedLegacyWorkspace = true;
  }

  workspace.eqFilters = sanitizeFilterList(saved?.eqFilters);
  workspace.gain = sanitizeVolumeGain(saved?.gain);
  workspace.sampleRate = sanitizeSampleRate(saved?.sampleRate);
  workspace.streams = sanitizeStreams(saved?.streams);

  // If the service worker restarted but the offscreen document did not survive,
  // no audio can still be playing, so drop stale stream entries.
  if (workspace.streams.length > 0) {
    const contexts = await chrome.runtime
      .getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [OFFSCREEN_URL]
      })
      .catch(() => []);

    if (contexts.length === 0) {
      workspace.streams = [];
      await persistWorkspace();
    } else {
      try {
        const response = await chrome.runtime.sendMessage({
          target: 'offscreen',
          command: 'getActiveTabs'
        });
        if (Array.isArray(response?.tabIds)) {
          const activeTabIds = new Set(response.tabIds);
          const liveStreams = workspace.streams.filter((stream) =>
            activeTabIds.has(stream.id)
          );
          if (liveStreams.length !== workspace.streams.length) {
            workspace.streams = liveStreams;
            await persistWorkspace();
          }
        }
      } catch (error) {
        // The offscreen document may still be starting; keep the saved state.
      }
    }
  }

  if (usedLegacyWorkspace) {
    await persistWorkspace();
  }
}

async function persistWorkspace() {
  await chrome.storage.session.set({
    [WORKSPACE_STORAGE_KEY]: workspaceSnapshot()
  });
}

function schedulePersist() {
  if (persistTimer) {
    return;
  }
  persistTimer = setTimeout(() => {
    persistTimer = null;
    void persistWorkspace().catch((error) => {
      console.warn('ieq: unable to persist workspace:', error);
    });
  }, 200);
}

async function flushPersist() {
  if (persistTimer) {
    clearTimeout(persistTimer);
    persistTimer = null;
  }
  await persistWorkspace();
}

async function persistPresets() {
  await chrome.storage.local.set({
    [PRESETS_STORAGE_KEY]: workspace.presets
  });
}

function cloneWorkspaceState() {
  return {
    eqFilters: workspace.eqFilters.map((filter) => ({ ...filter })),
    gain: workspace.gain,
    streams: workspace.streams.map((stream) => ({
      id: stream.id,
      title: stream.title,
      favIconUrl: stream.favIconUrl || ''
    }))
  };
}

let offscreenReady = false;
let offscreenCreation = null;

async function hasOffscreenDocument() {
  if (offscreenReady) {
    return true;
  }

  try {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [OFFSCREEN_URL]
    });
    offscreenReady = contexts.length > 0;
  } catch (error) {
    offscreenReady = false;
  }
  return offscreenReady;
}

async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    return;
  }

  if (!offscreenCreation) {
    offscreenCreation = chrome.offscreen
      .createDocument({
        url: OFFSCREEN_PATH,
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'Equalize captured tab audio and return FFT data for the visualizer.'
      })
      .finally(() => {
        offscreenCreation = null;
      });
  }

  try {
    await offscreenCreation;
    offscreenReady = true;
  } catch (error) {
    // A concurrent caller may have created the single allowed document.
    if (!(await hasOffscreenDocument())) {
      throw error;
    }
  }
}

async function sendToOffscreen(message) {
  await ensureOffscreenDocument();

  try {
    return await chrome.runtime.sendMessage({ target: 'offscreen', ...message });
  } catch (firstError) {
    offscreenReady = false;
    await ensureOffscreenDocument();
    return chrome.runtime.sendMessage({ target: 'offscreen', ...message });
  }
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return Number.isInteger(tab?.id) ? tab.id : null;
}

function broadcast(message) {
  chrome.runtime.sendMessage(message).catch(() => {
    // No receiver is expected while the popup is closed.
  });
}

function pushWorkspaceUpdates(activeTabId) {
  broadcast({ type: 'sendWorkspaceStatus', ...cloneWorkspaceState() });
  broadcast({ type: 'sendPresets', presets: workspace.presets });
  broadcast({ type: 'sendSampleRate', Fs: workspace.sampleRate });
  broadcast({
    type: 'sendCurrentTabStatus',
    tabId: Number.isInteger(activeTabId) ? activeTabId : null,
    streaming: Number.isInteger(activeTabId) && Boolean(findStream(activeTabId))
  });
  void updateActionIcon(activeTabId);
}

function findStream(tabId) {
  return workspace.streams.find((stream) => stream.id === tabId);
}

async function updateActionIcon(tabId, force = false) {
  if (!Number.isInteger(tabId)) {
    return;
  }

  const streaming = Boolean(findStream(tabId));
  if (!force && actionIconStates.get(tabId) === streaming) {
    return;
  }

  actionIconStates.set(tabId, streaming);
  try {
    await chrome.action.setIcon({
      tabId,
      path: streaming ? ACTION_ICON_ON : ACTION_ICON_OFF
    });
  } catch (error) {
    // A closed tab cannot carry an icon; let the next event try again.
    actionIconStates.delete(tabId);
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab) {
      console.warn('ieq: unable to update action icon:', error);
    }
  }
}

async function refreshActiveTabIcon() {
  await initWorkspace();
  const tabId = await getActiveTabId();
  await updateActionIcon(tabId);
}

async function startEqForTab(tabId) {
  if (!Number.isInteger(tabId)) {
    throw new Error('Invalid tab id.');
  }
  if (findStream(tabId) || startingTabs.has(tabId)) {
    return;
  }

  startingTabs.add(tabId);
  try {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
    const response = await sendToOffscreen({
      command: 'startTabAudio',
      tabId,
      streamId,
      filters: workspace.eqFilters,
      gain: workspace.gain
    });

    if (!response) {
      throw new Error('The audio engine did not respond.');
    }
    if (response.ok === false) {
      throw new Error(response.error || 'Unable to start audio processing.');
    }

    workspace.sampleRate = sanitizeSampleRate(response?.sampleRate);
    workspace.streams.push({
      id: tabId,
      title: tab?.title || `Tab ${tabId}`,
      favIconUrl: tab?.favIconUrl || ''
    });
    await flushPersist();
    await updateActionIcon(tabId);
  } finally {
    startingTabs.delete(tabId);
  }
}

async function stopEqForTab(tabId) {
  if (!Number.isInteger(tabId)) {
    return;
  }

  if (await hasOffscreenDocument()) {
    try {
      await sendToOffscreen({ command: 'stopTabAudio', tabId });
    } catch (error) {
      console.warn('ieq: unable to stop offscreen audio:', error);
    }
  }

  workspace.streams = workspace.streams.filter((stream) => stream.id !== tabId);
  await flushPersist();
  await updateActionIcon(tabId);
}

function applyPreset(name) {
  if (name === 'bassBoost') {
    workspace.eqFilters = workspace.eqFilters.map((filter) => {
      if (filter.type === 'lowshelf') {
        return { ...filter, gain: 10 };
      }
      if (filter.frequency < 250) {
        return { ...filter, gain: 5 };
      }
      if (filter.frequency > 6000) {
        return { ...filter, gain: -2 };
      }
      return { ...filter, gain: 0 };
    });
    return;
  }

  const preset = normalizePresetValue(workspace.presets[name]);
  if (!preset) {
    return;
  }

  workspace.eqFilters = preset.eqFilters.map((filter) => ({ ...filter }));
  workspace.gain = preset.gain;
}

async function syncProcessingNodes() {
  if (!(await hasOffscreenDocument())) {
    return;
  }

  try {
    await sendToOffscreen({
      command: 'updateAllFilters',
      filters: workspace.eqFilters,
      gain: workspace.gain
    });
  } catch (error) {
    console.warn('ieq: unable to update audio filters:', error);
  }
}

async function handleMessage(message) {
  await initWorkspace();

  switch (message.type) {
    case 'PING':
      return { reply: 'PONG' };

    case 'onPopupOpen':
    case 'getFullRefresh': {
      const tabId = Number.isInteger(message.tabId) ? message.tabId : await getActiveTabId();
      pushWorkspaceUpdates(tabId);
      return { ok: true };
    }

    case 'eqTab': {
      const tabId = Number.isInteger(message.tabId) ? message.tabId : await getActiveTabId();
      if (!Number.isInteger(tabId)) {
        throw new Error('No active tab to equalize.');
      }

      if (message.on) {
        await startEqForTab(tabId);
      } else {
        await stopEqForTab(tabId);
      }

      const streaming = Boolean(findStream(tabId));
      pushWorkspaceUpdates(tabId);
      return { ok: true, tabId, streaming };
    }

    case 'tabCaptureEnded': {
      const tabId = Number(message.tabId);
      if (Number.isInteger(tabId)) {
        workspace.streams = workspace.streams.filter((stream) => stream.id !== tabId);
        await flushPersist();
        pushWorkspaceUpdates(tabId);
      }
      return { ok: true };
    }

    case 'disconnectTab': {
      const tabId = Number(message.tab?.id);
      if (Number.isInteger(tabId)) {
        await stopEqForTab(tabId);
        pushWorkspaceUpdates(tabId);
      }
      return { ok: true };
    }

    case 'modifyFilter': {
      const index = Number(message.index);
      if (!Number.isInteger(index) || index < 0 || index >= FILTER_COUNT) {
        throw new Error('Invalid filter index.');
      }

      workspace.eqFilters[index] = sanitizeFilter(
        {
          ...workspace.eqFilters[index],
          frequency: message.frequency,
          gain: message.gain,
          q: message.q
        },
        DEFAULT_FILTERS[index]
      );
      await syncProcessingNodes();
      schedulePersist();
      pushWorkspaceUpdates();
      return { ok: true, filter: { ...workspace.eqFilters[index] } };
    }

    case 'resetFilter': {
      const index = Number(message.index);
      if (!Number.isInteger(index) || index < 0 || index >= FILTER_COUNT) {
        throw new Error('Invalid filter index.');
      }

      workspace.eqFilters[index] = { ...workspace.eqFilters[index], gain: 0 };
      await syncProcessingNodes();
      schedulePersist();
      pushWorkspaceUpdates();
      return { ok: true };
    }

    case 'modifyGain':
    case 'gainUpdated':
      workspace.gain = sanitizeVolumeGain(message.gain);
      await syncProcessingNodes();
      schedulePersist();
      pushWorkspaceUpdates();
      return { ok: true, gain: workspace.gain };

    case 'filterUpdated':
      await syncProcessingNodes();
      schedulePersist();
      pushWorkspaceUpdates();
      return { ok: true };

    case 'resetFilters':
      workspace.eqFilters = workspace.eqFilters.map((filter) => ({ ...filter, gain: 0 }));
      await syncProcessingNodes();
      schedulePersist();
      pushWorkspaceUpdates();
      return { ok: true };

    case 'preset':
      applyPreset(message.preset);
      await syncProcessingNodes();
      await flushPersist();
      pushWorkspaceUpdates();
      return { ok: true };

    case 'savePreset': {
      if (!isValidPresetName(message.preset)) {
        throw new Error(
          `Preset name must be 1-${MAX_PRESET_NAME_LENGTH} characters and not a reserved word.`
        );
      }
      workspace.presets[message.preset] = {
        eqFilters: workspace.eqFilters.map((filter) => ({ ...filter })),
        gain: workspace.gain
      };
      await persistPresets();
      broadcast({ type: 'sendPresets', presets: workspace.presets });
      return { ok: true };
    }

    case 'deletePreset': {
      if (!isValidPresetName(message.preset)) {
        throw new Error('Preset name is required.');
      }
      delete workspace.presets[message.preset];
      await persistPresets();
      broadcast({ type: 'sendPresets', presets: workspace.presets });
      return { ok: true };
    }

    case 'exportPresets': {
      const payload = JSON.stringify(workspace.presets, null, 2);
      const url = `data:application/json;charset=utf-8,${encodeURIComponent(payload)}`;
      await chrome.downloads.download({
        url,
        filename: 'ieq-presets.json',
        saveAs: true
      });
      return { ok: true };
    }

    case 'importPresets': {
      const imported = normalizeImportedPresets(message.presets);
      const importedCount = Object.keys(imported).length;
      workspace.presets = Object.assign(
        Object.create(null),
        workspace.presets,
        imported
      );
      await persistPresets();
      broadcast({ type: 'sendPresets', presets: workspace.presets });
      return { ok: true, imported: importedCount };
    }

    case 'getFFT': {
      const tabId = Number.isInteger(message.tabId) ? message.tabId : await getActiveTabId();
      if (!Number.isInteger(tabId) || !findStream(tabId)) {
        return { fft: [] };
      }

      const response = await sendToOffscreen({ command: 'getFFT', tabId });
      return response && Array.isArray(response.fft) ? response : { fft: [] };
    }

    default:
      return { ok: false, error: `Unknown message type: ${message.type}` };
  }
}

chrome.tabs.onActivated.addListener(({ tabId }) => {
  void (async () => {
    await initWorkspace();
    await updateActionIcon(tabId);
  })().catch((error) => {
    console.warn('ieq: unable to update action icon on tab activation:', error);
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  const navigating =
    changeInfo.status === 'loading' || changeInfo.status === 'complete';
  if (
    !navigating &&
    changeInfo.audible === undefined &&
    changeInfo.mutedInfo === undefined
  ) {
    return;
  }

  void (async () => {
    await initWorkspace();
    // Chrome drops per-tab action state when a tab navigates, so reapply it
    // there even when the cached streaming state is unchanged.
    await updateActionIcon(tabId, navigating);
  })().catch((error) => {
    console.warn('ieq: unable to update action icon on tab update:', error);
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  actionIconStates.delete(tabId);
  void (async () => {
    await initWorkspace();
    if (!findStream(tabId)) {
      return;
    }
    await stopEqForTab(tabId);
    pushWorkspaceUpdates();
  })().catch((error) => {
    console.error('ieq: error while cleaning up closed tab:', error);
  });
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('ieq installed/updated', chrome.runtime.getManifest().version);
  void refreshActiveTabIcon().catch((error) => {
    console.warn('ieq: unable to refresh action icon:', error);
  });
});

chrome.runtime.onStartup.addListener(() => {
  void refreshActiveTabIcon().catch((error) => {
    console.warn('ieq: unable to refresh action icon:', error);
  });
});

void initWorkspace();
void refreshActiveTabIcon().catch((error) => {
  console.warn('ieq: unable to refresh action icon:', error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== 'object' || message.target === 'offscreen') {
    return false;
  }
  if (typeof message.type !== 'string') {
    return false;
  }

  const responds = RESPONDING_MESSAGE_TYPES.has(message.type);

  void handleMessage(message)
    .then((result) => {
      if (responds) {
        sendResponse(result);
      }
    })
    .catch((error) => {
      console.error('ieq background error:', error);
      if (responds) {
        sendResponse(
          message.type === 'getFFT'
            ? { fft: [], error: error.message }
            : { ok: false, error: error.message }
        );
      }
    });

  return responds;
});
