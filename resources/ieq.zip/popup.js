'use strict';

(() => {
  const DEFAULT_SAMPLE_RATE = 44100;
  const MAX_FREQUENCY = 22050;
  const WIDTH = 600;
  const HEIGHT = 300;
  const GAIN_WIDTH = 30;

  const MIN_GAIN_DB = -30;
  const MAX_GAIN_DB = 30;
  const MAX_VOLUME_DB = 10;
  const MIN_Q = 0.2;
  const MAX_Q = 11;

  const FFT_INTERVAL_MS = 1000 / 30;
  const VISUALIZER_STORAGE_KEY = 'SHOW_VISUALIZER';
  const LAST_TAB_STORAGE_KEY = 'last-tab';
  const BASS_BOOST_PRESET = 'bassBoost';

  const COLORS = {
    background: '#1b2333',
    grid: '#33405a',
    shelf: '#d0bcff',
    peaking: '#9df0d2',
    fft: '#9df0d2'
  };

  const state = {
    activeTabId: null,
    sampleRate: DEFAULT_SAMPLE_RATE,
    eqFilters: [],
    volumeGain: 1,
    streams: [],
    streaming: false,
    dragging: false,
    visualizerOn: readStoredBoolean(VISUALIZER_STORAGE_KEY),
    fftTimer: null
  };

  const elements = {};
  const filterCurveNodes = new Map();

  let snapEq = null;
  let snapGain = null;
  let fftLine = null;
  let statusTimer = null;

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function toFiniteNumber(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function readStoredBoolean(key) {
    const value = localStorage.getItem(key);
    return value === '1' || value === 'true';
  }

  function gainToY(gainDb) {
    return HEIGHT * (1 - (gainDb - MIN_GAIN_DB) / (MAX_GAIN_DB - MIN_GAIN_DB));
  }

  function yToGain(y) {
    return (1 - y / HEIGHT) * (MAX_GAIN_DB - MIN_GAIN_DB) + MIN_GAIN_DB;
  }

  function frequencyToX(frequency) {
    return Math.pow(frequency / MAX_FREQUENCY, 1 / 4) * WIDTH;
  }

  function xToFrequency(x) {
    return Math.pow(x / WIDTH, 4) * MAX_FREQUENCY;
  }

  function dbToLinear(gainDb) {
    return Math.pow(10, gainDb / 10);
  }

  function linearToDb(gain) {
    return 10 * Math.log10(gain);
  }

  function elementOrigin(element) {
    // Snap's drag callbacks report page coordinates (client + scroll), so the
    // element origin must be converted to page coordinates as well.
    const rect = element?.node?.getClientRects?.()[0];
    return rect
      ? [rect.left + window.scrollX, rect.top + window.scrollY]
      : [window.scrollX, window.scrollY];
  }

  function send(message) {
    return chrome.runtime.sendMessage(message);
  }

  function showStatus(message, timeout = 4000) {
    if (!elements.statusMessage) {
      return;
    }

    elements.statusMessage.textContent = message;
    elements.statusMessage.classList.add('show');
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => {
      elements.statusMessage.classList.remove('show');
    }, timeout);
  }

  function cacheElements() {
    elements.eqTabButton = document.getElementById('eqTabButton');
    elements.eqTabLabel = document.getElementById('eqTabLabel');
    elements.headerStatusText = document.getElementById('headerStatusText');
    elements.eqTabList = document.getElementById('eqTabList');
    elements.presetNameInput = document.getElementById('presetNameInput');
    elements.savePresetButton = document.getElementById('savePresetButton');
    elements.deletePresetButton = document.getElementById('deletePresetButton');
    elements.resetFiltersButton = document.getElementById('resetFiltersButton');
    elements.bassBoostButton = document.getElementById('bassBoostButton');
    elements.exportPresetsButton = document.getElementById('exportPresetsButton');
    elements.importPresetsButton = document.getElementById('importPresetsButton');
    elements.importPresetsFile = document.getElementById('importPresetsFile');
    elements.userPresetSpan = document.getElementById('userPresetSpan');
    elements.vizButton = document.getElementById('vizButton');
    elements.statusMessage = document.getElementById('statusMessage');
    elements.fullscreenLink = document.getElementById('fullscreen-link');
  }

  /**
   * Transfer-function plot for one biquad, matching the Web Audio filters.
   * Kept numerically identical to the previous implementation.
   */
  function drawFilterCurve(filter, index) {
    if (!snapEq) {
      return;
    }

    const frequency = filter.frequency;
    const q = filter.q;
    const gainDb = filter.gain;
    const omega = Math.tan((Math.PI * frequency) / state.sampleRate);
    const amplitude = Math.pow(10, Math.abs(gainDb) / 20);

    let a0 = 0;
    let a1 = 0;
    let a2 = 0;
    let b1 = 0;
    let b2 = 0;
    let color = COLORS.grid;

    if (filter.type === 'peaking') {
      color = COLORS.peaking;
      if (gainDb >= 0) {
        const norm = 1 / (1 + (1 / q) * omega + omega * omega);
        a0 = (1 + (amplitude / q) * omega + omega * omega) * norm;
        a1 = 2 * (omega * omega - 1) * norm;
        a2 = (1 - (amplitude / q) * omega + omega * omega) * norm;
        b1 = a1;
        b2 = (1 - (1 / q) * omega + omega * omega) * norm;
      } else {
        const norm = 1 / (1 + (amplitude / q) * omega + omega * omega);
        a0 = (1 + (1 / q) * omega + omega * omega) * norm;
        a1 = 2 * (omega * omega - 1) * norm;
        a2 = (1 - (1 / q) * omega + omega * omega) * norm;
        b1 = a1;
        b2 = (1 - (amplitude / q) * omega + omega * omega) * norm;
      }
    } else if (filter.type === 'highshelf') {
      color = COLORS.shelf;
      if (gainDb >= 0) {
        const norm = 1 / (1 + Math.SQRT2 * omega + omega * omega);
        a0 = (amplitude + Math.sqrt(2 * amplitude) * omega + omega * omega) * norm;
        a1 = 2 * (omega * omega - amplitude) * norm;
        a2 = (amplitude - Math.sqrt(2 * amplitude) * omega + omega * omega) * norm;
        b1 = 2 * (omega * omega - 1) * norm;
        b2 = (1 - Math.SQRT2 * omega + omega * omega) * norm;
      } else {
        const norm = 1 / (amplitude + Math.sqrt(2 * amplitude) * omega + omega * omega);
        a0 = (1 + Math.SQRT2 * omega + omega * omega) * norm;
        a1 = 2 * (omega * omega - 1) * norm;
        a2 = (1 - Math.SQRT2 * omega + omega * omega) * norm;
        b1 = 2 * (omega * omega - amplitude) * norm;
        b2 = (amplitude - Math.sqrt(2 * amplitude) * omega + omega * omega) * norm;
      }
    } else if (filter.type === 'lowshelf') {
      color = COLORS.shelf;
      if (gainDb >= 0) {
        const norm = 1 / (1 + Math.SQRT2 * omega + omega * omega);
        a0 = (1 + Math.sqrt(2 * amplitude) * omega + amplitude * omega * omega) * norm;
        a1 = 2 * (amplitude * omega * omega - 1) * norm;
        a2 = (1 - Math.sqrt(2 * amplitude) * omega + amplitude * omega * omega) * norm;
        b1 = 2 * (omega * omega - 1) * norm;
        b2 = (1 - Math.SQRT2 * omega + omega * omega) * norm;
      } else {
        const norm = 1 / (1 + Math.sqrt(2 * amplitude) * omega + amplitude * omega * omega);
        a0 = (1 + Math.SQRT2 * omega + omega * omega) * norm;
        a1 = 2 * (omega * omega - 1) * norm;
        a2 = (1 - Math.SQRT2 * omega + omega * omega) * norm;
        b1 = 2 * (amplitude * omega * omega - 1) * norm;
        b2 = (1 - Math.sqrt(2 * amplitude) * omega + amplitude * omega * omega) * norm;
      }
    }

    const points = [];
    for (let x = 0; x < WIDTH; x += 2) {
      const normalized = Math.pow(x / WIDTH, 4) * Math.PI;
      const sinSquared = Math.pow(Math.sin(normalized / 2), 2);
      const ratio =
        (Math.pow(a0 + a1 + a2, 2) -
          4 * (a0 * a1 + 4 * a0 * a2 + a1 * a2) * sinSquared +
          16 * a0 * a2 * sinSquared * sinSquared) /
        (Math.pow(1 + b1 + b2, 2) -
          4 * (b1 + 4 * b2 + b1 * b2) * sinSquared +
          16 * b2 * sinSquared * sinSquared);

      const magnitude = (Math.log(ratio) * 10) / Math.LN10;
      let y = gainToY(magnitude);
      if (!Number.isFinite(y)) {
        y = HEIGHT - 1;
      }
      if (Math.abs(y - HEIGHT / 2) > 1) {
        points.push(x, y);
      }
    }

    const previous = filterCurveNodes.get(index);
    if (previous) {
      previous.remove();
    }
    filterCurveNodes.set(
      index,
      snapEq
        .polyline(points)
        .addClass('filterCurve')
        .attr({ stroke: color, 'fill-opacity': '0', 'pointer-events': 'none' })
    );
  }

  function drawGrid() {
    snapEq
      .line(0, gainToY(0), WIDTH, gainToY(0))
      .addClass('zeroLine');

    for (let frequency = 5; frequency < MAX_FREQUENCY; frequency *= 2) {
      const x = frequencyToX(frequency);
      snapEq
        .line(x, HEIGHT / 2 + 10, x, HEIGHT / 2 - 10)
        .attr({ stroke: COLORS.grid, 'stroke-opacity': 0.25 });
      snapEq.line(x, HEIGHT, x, HEIGHT - 15).attr({ stroke: COLORS.grid });
      const label = String(Math.round(xToFrequency(x)));
      const anchor = x > WIDTH - 20 ? 'end' : x < 20 ? 'start' : 'middle';
      snapEq
        .text(x, HEIGHT - 18, label)
        .attr({ fill: COLORS.grid, 'text-anchor': anchor, 'font-size': 10 });
      snapEq.line(x, 0, x, 15).attr({ stroke: COLORS.grid });
    }

    for (let gainDb = MIN_GAIN_DB; gainDb < MAX_GAIN_DB; gainDb += 10) {
      const y = gainToY(gainDb);
      snapEq.line(0, y, 5, y).attr({ stroke: COLORS.grid });
      snapEq
        .text(7, clamp(y, 6, HEIGHT - 6), String(gainDb))
        .attr({ fill: COLORS.grid, 'font-size': 10, 'dominant-baseline': 'middle' });
    }
  }

  function drawGainSlider() {
    const topY = gainToY(MAX_VOLUME_DB);
    const volumeDb = clamp(linearToDb(state.volumeGain), MIN_GAIN_DB, MAX_VOLUME_DB);
    const y = gainToY(volumeDb);

    snapGain
      .line(GAIN_WIDTH / 2, gainToY(MIN_GAIN_DB), GAIN_WIDTH / 2, topY)
      .addClass('gainRail');
    snapGain.line(0, gainToY(0), GAIN_WIDTH, gainToY(0)).addClass('gainZero');
    snapGain
      .text(GAIN_WIDTH / 2, topY - 9, 'volume')
      .attr({ 'text-anchor': 'middle' });

    const line = snapGain
      .line(3, y, GAIN_WIDTH - 3, y)
      .addClass('gainLine');
    const thumb = snapGain
      .circle(GAIN_WIDTH / 2, y, 5.5)
      .addClass('gainThumb');
    const hit = snapGain
      .line(0, y, GAIN_WIDTH, y)
      .addClass('gainHit');

    function moveTo(nextDb) {
      const nextY = gainToY(nextDb);
      line.attr({ y1: nextY, y2: nextY });
      thumb.attr({ cy: nextY });
      hit.attr({ y1: nextY, y2: nextY });
    }

    hit.drag(
      function onMove(dx, dy, clientX, clientY) {
        const [, top] = elementOrigin(snapGain);
        const nextY = clamp(clientY - top, 0, HEIGHT - 0.001);
        const nextDb = clamp(yToGain(nextY), MIN_GAIN_DB, MAX_VOLUME_DB);
        state.volumeGain = dbToLinear(nextDb);
        moveTo(nextDb);
        void send({
          type: 'modifyGain',
          gain: state.volumeGain,
          tabId: state.activeTabId
        });
      },
      function onStart() {
        state.dragging = true;
        snapGain.node.classList.add('dragging');
      },
      function onEnd() {
        state.dragging = false;
        snapGain.node.classList.remove('dragging');
        pulseElement(thumb);
        void send({
          type: 'gainUpdated',
          gain: state.volumeGain,
          tabId: state.activeTabId
        });
        void refreshWorkspace();
      }
    );
  }

  function pulseElement(element) {
    const node = element?.node;
    if (!node) {
      return;
    }
    node.classList.remove('pulse');
    void node.getBoundingClientRect();
    node.classList.add('pulse');
    setTimeout(() => node.classList.remove('pulse'), 450);
  }

  function makeFilterDragHandler(filter, index, dot) {
    return function onMove(dx, dy, clientX, clientY, event) {
      if (event?.shiftKey) {
        filter.q = clamp(filter.q + (event.movementY || 0) / 10, MIN_Q, MAX_Q);
      } else {
        const [left, top] = elementOrigin(snapEq);
        const x = clamp(clientX - left, 0, WIDTH - 0.001);
        const y = clamp(clientY - top, 0, HEIGHT - 0.001);
        filter.frequency = clamp(xToFrequency(x), 10, MAX_FREQUENCY);
        filter.gain = yToGain(y);
        dot.attr({ cx: x, cy: y });
      }

      drawFilterCurve(filter, index);
      void send({
        type: 'modifyFilter',
        index,
        frequency: filter.frequency,
        gain: filter.gain,
        q: filter.q,
        tabId: state.activeTabId
      });
    };
  }

  function makeFilterDragEndHandler(filter, index, dot) {
    return function onEnd() {
      state.dragging = false;
      dot.removeClass('dragging');
      pulseElement(dot);
      void send({
        type: 'filterUpdated',
        filterType: filter.type,
        frequency: filter.frequency,
        gain: filter.gain,
        q: filter.q,
        tabId: state.activeTabId
      });
      void refreshWorkspace();
    };
  }

  function renderGraph() {
    if (!window.Snap) {
      showStatus('The EQ renderer failed to load.');
      return;
    }

    if (snapEq) {
      snapEq.clear();
    }
    if (snapGain) {
      snapGain.clear();
    }
    filterCurveNodes.clear();
    fftLine = null;

    snapEq = window.Snap('#eqSvg');
    snapEq.attr({ fill: COLORS.background, height: HEIGHT, width: WIDTH });
    snapGain = window.Snap('#gainSvg');
    snapGain.attr({ fill: COLORS.background, height: HEIGHT, width: GAIN_WIDTH });
    snapGain.node.classList.remove('dragging');

    snapEq
      .rect(0, 0, WIDTH, HEIGHT)
      .attr({ fill: COLORS.background, stroke: COLORS.grid });

    state.eqFilters.forEach((filter, index) => drawFilterCurve(filter, index));
    drawGrid();
    drawGainSlider();

    state.eqFilters.forEach((filter, index) => {
      const dot = snapEq
        .circle(frequencyToX(filter.frequency), gainToY(filter.gain), 4)
        .addClass('filterDot')
        .addClass(filter.type === 'peaking' ? 'peaking' : 'shelf');

      dot.drag(
        makeFilterDragHandler(filter, index, dot),
        function onStart() {
          state.dragging = true;
          dot.addClass('dragging');
        },
        makeFilterDragEndHandler(filter, index, dot)
      );

      dot.dblclick(() => {
        filter.gain = 0;
        dot.attr({ cy: gainToY(0) });
        drawFilterCurve(filter, index);
        void send({ type: 'resetFilter', index, tabId: state.activeTabId });
      });
    });

    if (state.visualizerOn && state.streaming) {
      startFftLoop();
    }
  }

  function drawFft(fft) {
    if (!snapEq) {
      return;
    }
    if (fftLine) {
      fftLine.remove();
      fftLine = null;
    }
    if (!state.visualizerOn || !Array.isArray(fft) || fft.length === 0) {
      return;
    }

    const points = [];

    for (let i = 0; i < fft.length; i += 1) {
      const frequency = (i * state.sampleRate) / (fft.length * 2);
      if (frequency < 10) {
        continue;
      }

      const x = frequencyToX(frequency);
      if (x > WIDTH) {
        break;
      }

      const level = toFiniteNumber(fft[i], -100);
      const plotHeight = HEIGHT - 28;
      const y = ((level + 100) / 100) * plotHeight;
      points.push([x, plotHeight - y]);
    }

    const merged = [];
    for (const point of points) {
      const last = merged[merged.length - 1];
      if (!last) {
        merged.push(point);
        continue;
      }
      if (point[0] - last[0] < 2) {
        last[1] = Math.max(last[1], point[1]);
      } else {
        merged.push(point);
      }
    }

    const path = [];
    for (const [x, y] of merged) {
      path.push(x, y);
    }

    fftLine = snapEq
      .polyline(path)
      .addClass('fftLine')
      .attr({ 'fill-opacity': '0', stroke: COLORS.fft, 'pointer-events': 'none' });
  }

  function startFftLoop() {
    stopFftLoop();
    const tick = () => {
      if (!state.visualizerOn) {
        return;
      }

      const startedAt = performance.now();
      const request = state.activeTabId
        ? send({ type: 'getFFT', tabId: state.activeTabId })
        : Promise.resolve({ fft: [] });

      void request
        .then((response) => drawFft(response?.fft || []))
        .catch(() => {})
        .finally(() => {
          if (!state.visualizerOn) {
            return;
          }
          const elapsed = performance.now() - startedAt;
          state.fftTimer = setTimeout(tick, Math.max(0, FFT_INTERVAL_MS - elapsed));
        });
    };
    tick();
  }

  function stopFftLoop() {
    if (state.fftTimer) {
      clearTimeout(state.fftTimer);
      state.fftTimer = null;
    }
    if (fftLine) {
      fftLine.remove();
      fftLine = null;
    }
  }

  function setVisualizerUi() {
    elements.vizButton.classList.toggle('on', state.visualizerOn);
    elements.vizButton.setAttribute('aria-pressed', String(state.visualizerOn));
  }

  function toggleVisualizer() {
    state.visualizerOn = !state.visualizerOn;
    localStorage.setItem(VISUALIZER_STORAGE_KEY, state.visualizerOn ? '1' : '0');
    setVisualizerUi();

    if (state.visualizerOn && state.streaming) {
      startFftLoop();
    } else {
      stopFftLoop();
    }
  }

  function updateHeaderStatus() {
    if (!elements.headerStatusText) {
      return;
    }

    const rate = state.sampleRate
      ? `${Math.round(state.sampleRate / 1000)} kHz`
      : '';
    elements.headerStatusText.textContent = state.streaming
      ? rate
        ? `Live · ${rate}`
        : 'Live'
      : 'Standby';
  }

  function updateEqButton() {
    if (!elements.eqTabButton) {
      return;
    }

    const label = elements.eqTabLabel || elements.eqTabButton;
    label.textContent = state.streaming
      ? 'Stop EQing This Tab'
      : 'EQ This Tab';
    elements.eqTabButton.classList.toggle('streaming', state.streaming);
    document.body.classList.toggle('is-live', state.streaming);
    updateHeaderStatus();
  }

  function setStreaming(streaming) {
    state.streaming = Boolean(streaming);
    if (!state.streaming) {
      stopFftLoop();
    } else if (state.visualizerOn) {
      startFftLoop();
    }
    updateEqButton();
  }

  function renderTabList() {
    elements.eqTabList.textContent = '';

    if (state.streams.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';

      const orbit = document.createElement('div');
      orbit.className = 'empty-orbit';
      orbit.append(document.createElement('i'));

      const copy = document.createElement('p');
      copy.textContent =
        'No tabs are active. Open a page with audio, then choose EQ This Tab.';

      empty.append(orbit, copy);
      elements.eqTabList.append(empty);
      return;
    }

    for (const stream of state.streams) {
      const isCurrent = stream.id === state.activeTabId;
      const row = document.createElement('div');
      row.className = 'tab-row';
      row.classList.toggle('is-current', isCurrent);

      const icon = document.createElement('img');
      icon.className = 'tab-favicon';
      icon.alt = '';
      icon.src = stream.favIconUrl || 'logo/ieq-32.png';
      icon.addEventListener(
        'error',
        () => {
          icon.src = 'logo/ieq-32.png';
        },
        { once: true }
      );

      const title = document.createElement('span');
      title.className = 'tab-title';
      const titleText =
        typeof stream.title === 'string' ? stream.title : `Tab ${stream.id}`;
      title.textContent =
        titleText.length > 60 ? `${titleText.slice(0, 60)}…` : titleText;

      row.append(icon, title);

      if (isCurrent) {
        const currentDot = document.createElement('span');
        currentDot.className = 'tab-current-dot';
        currentDot.title = 'This tab';
        row.append(currentDot);
      }

      const stop = document.createElement('button');
      stop.type = 'button';
      stop.className = 'tab-stop';
      stop.textContent = 'Stop';
      stop.addEventListener('click', () => {
        void send({ type: 'disconnectTab', tab: stream });
      });
      row.append(stop);

      elements.eqTabList.append(row);
    }
  }

  function renderPresets(presets) {
    elements.userPresetSpan.textContent = '';

    for (const name of Object.keys(presets || {})) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = name;
      button.addEventListener('click', () => {
        void send({ type: 'preset', preset: name, tabId: state.activeTabId });
        elements.presetNameInput.value = name;
      });
      elements.userPresetSpan.appendChild(button);
    }
  }

  function applyWorkspace(workspace) {
    if (!state.dragging) {
      state.eqFilters = Array.isArray(workspace.eqFilters)
        ? workspace.eqFilters.map((filter) => ({ ...filter }))
        : [];
      state.volumeGain = toFiniteNumber(workspace.gain, 1);
      renderGraph();
    }

    state.streams = Array.isArray(workspace.streams) ? workspace.streams : [];
    setStreaming(
      state.streams.some((stream) => stream.id === state.activeTabId)
    );
    renderTabList();
  }

  function applySampleRate(sampleRate) {
    const rate = toFiniteNumber(sampleRate, state.sampleRate);
    if (rate === state.sampleRate) {
      return;
    }
    state.sampleRate = rate;
    updateHeaderStatus();
    if (!state.dragging) {
      renderGraph();
    }
  }

  async function refreshWorkspace() {
    await send({ type: 'getFullRefresh', tabId: state.activeTabId });
  }

  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab || null;
  }

  async function startEq({ silent = false } = {}) {
    const tab = await getActiveTab();
    if (!tab?.id) {
      if (!silent) {
        showStatus('No active tab found.');
      }
      return;
    }

    state.activeTabId = tab.id;
    try {
      const response = await send({ type: 'eqTab', on: true, tabId: tab.id });
      if (!response?.ok) {
        throw new Error(response?.error || 'Unable to start EQ.');
      }
      setStreaming(Boolean(response.streaming));
    } catch (error) {
      setStreaming(false);
      if (silent) {
        console.warn('ieq: automatic capture failed:', error.message);
      } else {
        showStatus(error.message);
      }
    }
  }

  async function stopEq() {
    if (!state.activeTabId) {
      return;
    }

    try {
      const response = await send({
        type: 'eqTab',
        on: false,
        tabId: state.activeTabId
      });
      if (!response?.ok) {
        throw new Error(response?.error || 'Unable to stop EQ.');
      }
      setStreaming(false);
    } catch (error) {
      showStatus(error.message);
    }
  }

  function savePreset() {
    const name = elements.presetNameInput.value.trim();
    if (!name) {
      showStatus('Type a name in the Preset Name box, then click Save Preset.');
      elements.presetNameInput.focus();
      return;
    }

    void send({ type: 'savePreset', preset: name })
      .then((response) => {
        if (!response?.ok) {
          throw new Error(response?.error || 'Unable to save the preset.');
        }
        showStatus(`Preset "${name}" saved.`);
      })
      .catch((error) => showStatus(error.message));
  }

  function deletePreset() {
    const name = elements.presetNameInput.value.trim();
    if (!name) {
      showStatus('Select or type a preset name to delete.');
      return;
    }

    void send({ type: 'deletePreset', preset: name })
      .then((response) => {
        if (!response?.ok) {
          throw new Error(response?.error || 'Unable to delete the preset.');
        }
        showStatus(`Preset "${name}" deleted.`);
      })
      .catch((error) => showStatus(error.message));
  }

  function importPresets(file) {
    void file
      .text()
      .then((text) => {
        let parsed;
        try {
          parsed = JSON.parse(text);
        } catch (error) {
          throw new Error('That file is not valid JSON.');
        }
        return send({ type: 'importPresets', presets: parsed });
      })
      .then((response) => {
        if (!response?.ok) {
          throw new Error(response?.error || 'Unable to import presets.');
        }
        const count = Number(response.imported) || 0;
        showStatus(
          count > 0
            ? `Imported ${count} preset${count === 1 ? '' : 's'}.`
            : 'No valid presets were found in that file.'
        );
      })
      .catch((error) => showStatus(error.message))
      .finally(() => {
        elements.importPresetsFile.value = '';
      });
  }

  function wireControls() {
    elements.resetFiltersButton.addEventListener('click', () => {
      elements.presetNameInput.value = '';
      void send({ type: 'resetFilters', tabId: state.activeTabId });
    });

    elements.bassBoostButton.addEventListener('click', () => {
      elements.presetNameInput.value = '';
      void send({
        type: 'preset',
        preset: BASS_BOOST_PRESET,
        tabId: state.activeTabId
      });
    });

    elements.savePresetButton.addEventListener('click', savePreset);
    elements.deletePresetButton.addEventListener('click', deletePreset);

    elements.presetNameInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        savePreset();
      }
    });

    elements.exportPresetsButton.addEventListener('click', () => {
      void send({ type: 'exportPresets' })
        .then((response) => {
          if (!response?.ok) {
            throw new Error(response?.error || 'Unable to export presets.');
          }
          showStatus('Preset file prepared.');
        })
        .catch((error) => showStatus(error.message));
    });

    elements.importPresetsButton.addEventListener('click', () => {
      elements.importPresetsFile.click();
    });

    elements.importPresetsFile.addEventListener('change', () => {
      const file = elements.importPresetsFile.files?.[0];
      if (file) {
        importPresets(file);
      }
    });

    elements.vizButton.addEventListener('click', toggleVisualizer);

    elements.eqTabButton.addEventListener('click', () => {
      if (state.streaming) {
        void stopEq();
      } else {
        void startEq();
      }
    });

    for (const tabId of ['tab-1', 'tab-2', 'tab-3']) {
      const input = document.getElementById(tabId);
      input?.addEventListener('change', () => {
        if (input.checked) {
          localStorage.setItem(LAST_TAB_STORAGE_KEY, tabId);
        }
      });
    }

    const lastTab = localStorage.getItem(LAST_TAB_STORAGE_KEY);
    if (lastTab) {
      document.getElementById(lastTab)?.click();
    }

    if (window.innerWidth && window.innerWidth > 1000) {
      elements.fullscreenLink.style.display = 'none';
    }
  }

  function wireMessages() {
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || typeof message !== 'object') {
        return;
      }

      switch (message.type) {
        case 'sendWorkspaceStatus':
          applyWorkspace(message);
          break;
        case 'sendPresets':
          renderPresets(message.presets);
          break;
        case 'sendSampleRate':
          applySampleRate(message.Fs);
          break;
        case 'sendCurrentTabStatus':
          if (message.tabId === state.activeTabId) {
            setStreaming(Boolean(message.streaming));
          }
          break;
        default:
          break;
      }
    });
  }

  async function init() {
    cacheElements();
    wireControls();
    wireMessages();
    setVisualizerUi();
    updateEqButton();
    renderGraph();
    renderTabList();

    const tab = await getActiveTab();
    if (tab?.id) {
      state.activeTabId = tab.id;
      updateEqButton();
      void refreshWorkspace();

      // A real action popup is not a tab. Only auto-connect that context so the
      // full-window view never tries to capture itself.
      const currentTab = await chrome.tabs.getCurrent().catch(() => null);
      if (!currentTab) {
        await startEq({ silent: true });
      }
    }

    if (state.visualizerOn && state.streaming) {
      startFftLoop();
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    void init();
  });
})();
